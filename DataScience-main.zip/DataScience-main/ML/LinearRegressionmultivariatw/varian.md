
``Python
with open('model_pickle','rb') as file:
  mp=pickle.load(file)
``
