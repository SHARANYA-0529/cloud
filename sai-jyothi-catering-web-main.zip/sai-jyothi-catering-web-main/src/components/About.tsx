import { Card } from '@/components/ui/card';
import { Users, Clock, Heart, Star } from 'lucide-react';

export const About = () => {
  const features = [
    {
      icon: Users,
      title: "Expert Team",
      description: "Professional chefs and service staff dedicated to excellence"
    },
    {
      icon: Clock,
      title: "Timely Service",
      description: "Always on time, ensuring your event runs smoothly"
    },
    {
      icon: Heart,
      title: "Made with Love",
      description: "Every dish prepared with passion and attention to detail"
    },
    {
      icon: Star,
      title: "Premium Quality",
      description: "Only the finest ingredients for exceptional taste"
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-warm-cream to-primary-light">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              About <span className="text-primary">Sri Sai Jyothi Caterers</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-primary-dark mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              At Sri Sai Jyothi Caterers, we specialize in crafting delicious, high-quality food experiences 
              for weddings, parties, events, and more. From traditional vegetarian feasts to rich non-veg dishes, 
              we serve taste with commitment.
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div>
              <div className="bg-white rounded-2xl p-8 shadow-soft border border-border">
                <h3 className="text-2xl font-bold mb-4 text-foreground">Our Story</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Founded with a passion for exceptional cuisine and service, Sri Sai Jyothi Caterers 
                  has been serving the Gajwel and Siddipet region with pride. Our journey began with 
                  a simple mission: to create memorable dining experiences that bring people together.
                </p>
                
                <div className="space-y-4">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    <span className="text-foreground">Fresh ingredients sourced daily</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    <span className="text-foreground">Hygienic food preparation</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    <span className="text-foreground">Professional service team</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    <span className="text-foreground">Customizable menu options</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Content - Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <Card key={index} className="p-6 text-center hover:shadow-soft transition-all duration-300 hover:-translate-y-1 bg-white border-border">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary-dark rounded-full flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <h4 className="text-lg font-semibold mb-2 text-foreground">{feature.title}</h4>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </Card>
              ))}
            </div>
          </div>

          {/* Owner Info */}
          <div className="mt-16 text-center bg-white rounded-2xl p-8 shadow-soft border border-border">
            <div className="max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold mb-4 text-foreground">Meet Our Founder</h3>
              <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-6">
                <div className="w-20 h-20 bg-gradient-to-br from-primary to-primary-dark rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-2xl">M</span>
                </div>
                <div className="text-center md:text-left">
                  <h4 className="text-xl font-semibold text-foreground">S. Mallesh Goud</h4>
                  <p className="text-muted-foreground">Founder & Managing Director</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    "Our commitment is to make every celebration memorable through exceptional food and service."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};