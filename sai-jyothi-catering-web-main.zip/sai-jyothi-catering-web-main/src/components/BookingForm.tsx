import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { Calendar, Users, MapPin, Phone, Mail, Send } from 'lucide-react';

export const BookingForm = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    email: '',
    eventType: '',
    guests: '',
    location: '',
    menuType: '',
    date: '',
    notes: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name || !formData.mobile || !formData.eventType || !formData.guests || !formData.location || !formData.menuType || !formData.date) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    // Create WhatsApp message
    const message = `🎉 *New Catering Booking Request*

👤 *Name:* ${formData.name}
📱 *Mobile:* ${formData.mobile}
📧 *Email:* ${formData.email || 'Not provided'}
🎊 *Event Type:* ${formData.eventType}
👥 *Number of Guests:* ${formData.guests}
📍 *Location:* ${formData.location}
🍽️ *Menu Type:* ${formData.menuType}
📅 *Date:* ${formData.date}
📝 *Special Notes:* ${formData.notes || 'None'}

Thank you for choosing Sri Sai Jyothi Caterers! 🙏`;

    // Open WhatsApp with pre-filled message
    const whatsappUrl = `https://wa.me/919440363308?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');

    toast({
      title: "Booking Request Sent!",
      description: "Your booking request has been sent via WhatsApp. We'll contact you soon!",
    });

    // Reset form
    setFormData({
      name: '',
      mobile: '',
      email: '',
      eventType: '',
      guests: '',
      location: '',
      menuType: '',
      date: '',
      notes: ''
    });
  };

  return (
    <section id="contact" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              Book Your <span className="text-primary">Event</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-primary-dark mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Ready to make your event memorable? Fill out the form below and we'll get back to you 
              with a customized quote for your special occasion.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div className="lg:col-span-1">
              <Card className="border-border h-fit">
                <CardHeader>
                  <CardTitle className="text-foreground">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium text-foreground">Phone Numbers</p>
                      <p className="text-sm text-muted-foreground">9440363308</p>
                      <p className="text-sm text-muted-foreground">9246963308</p>
                      <p className="text-sm text-muted-foreground">9959906455</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium text-foreground">Email</p>
                      <p className="text-sm text-muted-foreground">malleshgoud363308@gmail.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium text-foreground">Location</p>
                      <p className="text-sm text-muted-foreground">Gajwel, Siddipet District</p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-border">
                    <h3 className="font-medium text-foreground mb-3">Quick Contact</h3>
                    <div className="flex flex-col space-y-2">
                      <a
                        href="https://wa.me/919440363308"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center py-2 px-4 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                      >
                        WhatsApp
                      </a>
                      <a
                        href="tel:+919440363308"
                        className="flex items-center justify-center py-2 px-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary-dark transition-colors"
                      >
                        Call Now
                      </a>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Booking Form */}
            <div className="lg:col-span-2">
              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Booking Form</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Personal Information */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Full Name *</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                          placeholder="Enter your full name"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="mobile">Mobile Number *</Label>
                        <Input
                          id="mobile"
                          type="tel"
                          value={formData.mobile}
                          onChange={(e) => handleInputChange('mobile', e.target.value)}
                          placeholder="Enter your mobile number"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">Email (Optional)</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="Enter your email address"
                      />
                    </div>

                    {/* Event Details */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="eventType">Event Type *</Label>
                        <Select value={formData.eventType} onValueChange={(value) => handleInputChange('eventType', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select event type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="wedding">Wedding</SelectItem>
                            <SelectItem value="party">Birthday Party</SelectItem>
                            <SelectItem value="corporate">Corporate Event</SelectItem>
                            <SelectItem value="housewarming">Housewarming</SelectItem>
                            <SelectItem value="engagement">Engagement</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="guests">Number of Guests *</Label>
                        <Input
                          id="guests"
                          type="number"
                          value={formData.guests}
                          onChange={(e) => handleInputChange('guests', e.target.value)}
                          placeholder="e.g., 100"
                          min="1"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="location">Event Location *</Label>
                      <Input
                        id="location"
                        value={formData.location}
                        onChange={(e) => handleInputChange('location', e.target.value)}
                        placeholder="Enter event venue/location"
                        required
                      />
                    </div>

                    <div>
                      <Label>Menu Type *</Label>
                      <RadioGroup 
                        value={formData.menuType} 
                        onValueChange={(value) => handleInputChange('menuType', value)}
                        className="flex flex-col space-y-2 mt-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="veg" id="veg" />
                          <Label htmlFor="veg">Vegetarian Only</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="non-veg" id="non-veg" />
                          <Label htmlFor="non-veg">Non-Vegetarian Only</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="both" id="both" />
                          <Label htmlFor="both">Both Veg & Non-Veg</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div>
                      <Label htmlFor="date">Event Date *</Label>
                      <Input
                        id="date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => handleInputChange('date', e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="notes">Special Notes</Label>
                      <Textarea
                        id="notes"
                        value={formData.notes}
                        onChange={(e) => handleInputChange('notes', e.target.value)}
                        placeholder="Any special requirements or additional information..."
                        rows={4}
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-primary to-primary-dark hover:shadow-warm text-lg py-3"
                    >
                      <Send className="h-5 w-5 mr-2" />
                      Send Booking Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};