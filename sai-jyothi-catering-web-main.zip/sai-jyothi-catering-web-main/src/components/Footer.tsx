import { Phone, Mail, MapPin, Heart } from 'lucide-react';

export const Footer = () => {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gradient-to-br from-primary-dark to-foreground text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">S</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">Sri Sai Jyothi Caterers</h3>
                <p className="text-sm opacity-80">Events & Catering</p>
              </div>
            </div>
            <p className="text-sm opacity-90 leading-relaxed mb-4">
              Creating memorable culinary experiences for your special occasions. 
              We specialize in traditional and contemporary catering services with 
              a commitment to quality, taste, and satisfaction.
            </p>
            <p className="text-sm font-medium">
              "We Mean Taste, Quality & Satisfaction"
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection('#home')}
                  className="text-sm opacity-90 hover:opacity-100 hover:text-primary transition-all"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('#about')}
                  className="text-sm opacity-90 hover:opacity-100 hover:text-primary transition-all"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('#menu')}
                  className="text-sm opacity-90 hover:opacity-100 hover:text-primary transition-all"
                >
                  Our Menu
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('#gallery')}
                  className="text-sm opacity-90 hover:opacity-100 hover:text-primary transition-all"
                >
                  Gallery
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('#contact')}
                  className="text-sm opacity-90 hover:opacity-100 hover:text-primary transition-all"
                >
                  Book Order
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Information</h4>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-primary" />
                <div>
                  <p className="text-sm">9440363308</p>
                  <p className="text-sm">9246963308</p>
                  <p className="text-sm">9959906455</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-primary" />
                <p className="text-sm">malleshgoud363308@gmail.com</p>
              </div>
              
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-primary" />
                <p className="text-sm">Gajwel, Siddipet District</p>
              </div>
            </div>

            <div className="mt-6">
              <p className="text-sm font-medium mb-2">Owner & Managing Director</p>
              <p className="text-sm opacity-90">S. Mallesh Goud</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-primary-foreground/20 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm opacity-80 mb-4 md:mb-0">
              © 2025 Sri Sai Jyothi Caterers. All rights reserved.
            </p>
            <p className="text-sm opacity-80 flex items-center">
              Made with <Heart className="h-4 w-4 mx-1 text-red-400" /> for delicious celebrations
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};