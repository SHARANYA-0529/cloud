import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Eye, X } from 'lucide-react';

// Import food images
import chickenBiryani from '@/assets/chicken-biryani.jpg';
import muttonBiryani from '@/assets/mutton-biryani.jpg';
import fishFry from '@/assets/fish-fry.jpg';
import muttonCurry from '@/assets/mutton-curry.jpg';
import chickenCurry from '@/assets/chicken-curry.jpg';
import rumaliRoti from '@/assets/rumali-roti.jpg';
import doubleKaMeetha from '@/assets/double-ka-meetha.jpg';
import kadduKheer from '@/assets/kaddu-kheer.jpg';
import chatItems from '@/assets/chat-items.jpg';
import indianThali from '@/assets/indian-thali.jpg';

export const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  // Signature food items with generated images
  const galleryImages = [
    // Signature Dishes
    {
      src: chickenBiryani,
      alt: "Chicken Biryani",
      category: "Biryani"
    },
    {
      src: muttonBiryani,
      alt: "Mutton Biryani", 
      category: "Biryani"
    },
    {
      src: fishFry,
      alt: "Fish Fry",
      category: "Non-Veg"
    },
    {
      src: muttonCurry,
      alt: "Mutton Curry",
      category: "Non-Veg"
    },
    {
      src: chickenCurry,
      alt: "Chicken Curry",
      category: "Non-Veg"
    },
    {
      src: rumaliRoti,
      alt: "Rumali Roti",
      category: "Breads"
    },
    {
      src: doubleKaMeetha,
      alt: "Double Ka Meetha",
      category: "Desserts"
    },
    {
      src: kadduKheer,
      alt: "Kaddu Ka Kheer",
      category: "Desserts"
    },
    {
      src: chatItems,
      alt: "Chat Items",
      category: "Snacks"
    },
    {
      src: indianThali,
      alt: "Traditional Indian Thali",
      category: "Traditional"
    },
    // Event setup images
    {
      src: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      alt: "Wedding Buffet Setup",
      category: "Events"
    },
    {
      src: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      alt: "Elegant Event Setup",
      category: "Events"
    },
    {
      src: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      alt: "Gourmet Appetizers",
      category: "Snacks"
    },
    {
      src: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      alt: "Corporate Catering",
      category: "Events"
    },
    {
      src: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      alt: "Party Setup",
      category: "Events"
    }
  ];

  const categories = ['All', 'Biryani', 'Non-Veg', 'Traditional', 'Desserts', 'Snacks', 'Breads', 'Events'];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredImages = activeCategory === 'All' 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  return (
    <section id="gallery" className="py-20 bg-gradient-to-br from-background to-accent">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              Our <span className="text-primary">Gallery</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-primary-dark mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Take a visual journey through our culinary creations and event setups. 
              Each image tells a story of quality, presentation, and satisfied guests.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={activeCategory === category ? "default" : "outline"}
                className={`cursor-pointer px-4 py-2 transition-all duration-300 ${
                  activeCategory === category 
                    ? "bg-primary text-primary-foreground" 
                    : "hover:bg-primary/10"
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredImages.map((image, index) => (
              <Card 
                key={index} 
                className="group relative overflow-hidden border-border hover:shadow-soft transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedImage(index)}
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/50 transition-all duration-300 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-center">
                      <Eye className="h-8 w-8 text-white mx-auto mb-2" />
                      <p className="text-white font-medium">{image.alt}</p>
                      <Badge variant="secondary" className="mt-2">
                        {image.category}
                      </Badge>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Lightbox Modal */}
          {selectedImage !== null && (
            <div 
              className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedImage(null)}
            >
              <div className="relative max-w-4xl max-h-full">
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-12 right-0 text-white hover:text-gray-300 transition-colors"
                >
                  <X className="h-8 w-8" />
                </button>
                <img
                  src={filteredImages[selectedImage].src}
                  alt={filteredImages[selectedImage].alt}
                  className="max-w-full max-h-full object-contain rounded-lg"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 rounded-b-lg">
                  <h3 className="text-white font-semibold text-lg">
                    {filteredImages[selectedImage].alt}
                  </h3>
                  <Badge variant="secondary" className="mt-2">
                    {filteredImages[selectedImage].category}
                  </Badge>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};