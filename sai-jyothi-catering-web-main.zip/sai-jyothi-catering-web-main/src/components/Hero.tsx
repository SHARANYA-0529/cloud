import { Button } from '@/components/ui/button';
import { Star, Users, Calendar, Award } from 'lucide-react';
import heroImage from '@/assets/hero-catering.jpg';

export const Hero = () => {
  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-golden to-primary bg-clip-text text-transparent">
              Sri Sai Jyothi
            </span>
            <br />
            <span className="text-white">Caterers</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-4 text-gray-200">
            We Mean Taste, Quality & Satisfaction
          </p>
          
          <p className="text-lg mb-8 max-w-2xl mx-auto text-gray-300">
            Experience the finest in traditional and contemporary catering services. 
            From intimate gatherings to grand celebrations, we create unforgettable culinary experiences.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg"
              onClick={scrollToContact}
              className="bg-gradient-to-r from-primary to-primary-dark hover:shadow-warm text-lg px-8 py-3 transition-all duration-300 hover:scale-105"
            >
              📲 Book Catering Now
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => document.querySelector('#menu')?.scrollIntoView({ behavior: 'smooth' })}
              className="border-white text-white hover:bg-white hover:text-foreground text-lg px-8 py-3 transition-all duration-300"
            >
              View Menu
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Star className="h-6 w-6 text-golden mr-2" />
                <span className="text-2xl font-bold">500+</span>
              </div>
              <p className="text-sm text-gray-300">Happy Events</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="h-6 w-6 text-golden mr-2" />
                <span className="text-2xl font-bold">50K+</span>
              </div>
              <p className="text-sm text-gray-300">Guests Served</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Calendar className="h-6 w-6 text-golden mr-2" />
                <span className="text-2xl font-bold">10+</span>
              </div>
              <p className="text-sm text-gray-300">Years Experience</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Award className="h-6 w-6 text-golden mr-2" />
                <span className="text-2xl font-bold">100%</span>
              </div>
              <p className="text-sm text-gray-300">Satisfaction</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};