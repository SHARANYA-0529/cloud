import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Leaf, Utensils, Download, Star } from 'lucide-react';

export const Menu = () => {
  const [activeTab, setActiveTab] = useState('veg');

  const vegMenuItems = [
    {
      category: "Welcome Drinks",
      items: ["Fresh Lime Water", "Buttermilk", "Rose Milk", "Badam Milk", "Fruit Juices"]
    },
    {
      category: "Snacks & Starters",
      items: ["Samosa", "Pakoda", "Dhokla", "Paneer Tikka", "Aloo Bonda", "Mirchi Bajji"]
    },
    {
      category: "Chat Items",
      items: ["Bhel Puri", "Pani Puri", "Dahi Puri", "Aloo Chat", "Masala Puri"]
    },
    {
      category: "Chinese",
      items: ["Veg Fried Rice", "Veg Noodles", "Gobi Manchurian", "Paneer Chilli"]
    },
    {
      category: "Main Course",
      items: ["Dal Tadka", "Rajma", "Chole", "Paneer Butter Masala", "Aloo Jeera", "Mix Veg Curry"]
    },
    {
      category: "Rice & Rotis",
      items: ["Veg Biryani", "Jeera Rice", "Curd Rice", "Chapati", "Naan", "Parathas"]
    },
    {
      category: "Sweets & Desserts",
      items: ["Gulab Jamun", "Rasmalai", "Kheer", "Halwa", "Ice Cream", "Kulfi"]
    }
  ];

  const nonVegMenuItems = [
    {
      category: "Non-Veg Starters",
      items: ["Chicken 65", "Chicken Tikka", "Mutton Fry", "Fish Fry", "Prawns Fry", "Tandoori Chicken"]
    },
    {
      category: "Chicken Items",
      items: ["Chicken Curry", "Butter Chicken", "Chicken Biryani", "Chicken Fry", "Chicken Masala"]
    },
    {
      category: "Mutton Items",
      items: ["Mutton Curry", "Mutton Biryani", "Mutton Fry", "Mutton Masala", "Mutton Roast"]
    },
    {
      category: "Fish & Seafood",
      items: ["Fish Curry", "Fish Fry", "Prawns Curry", "Crab Masala", "Fish Biryani"]
    },
    {
      category: "Special Biryanis",
      items: ["Hyderabadi Chicken Biryani", "Mutton Biryani", "Fish Biryani", "Egg Biryani"]
    },
    {
      category: "Soups",
      items: ["Chicken Soup", "Mutton Soup", "Fish Soup", "Hot & Sour Soup"]
    },
    {
      category: "Rice & Breads",
      items: ["Chicken Fried Rice", "Egg Fried Rice", "Butter Naan", "Rumali Roti"]
    }
  ];

  const downloadMenu = (type: string) => {
    // In a real app, this would download the actual PDF
    alert(`Downloading ${type} menu PDF...`);
  };

  return (
    <section id="menu" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              Our <span className="text-primary">Delicious Menu</span>
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-primary to-primary-dark mx-auto mb-6"></div>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Explore our extensive collection of traditional and contemporary dishes, 
              carefully crafted to delight your taste buds and make your event memorable.
            </p>
          </div>

          {/* Menu Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-12 h-14">
              <TabsTrigger 
                value="veg" 
                className="flex items-center space-x-2 text-lg py-3"
              >
                <Leaf className="h-5 w-5" />
                <span>Vegetarian</span>
              </TabsTrigger>
              <TabsTrigger 
                value="non-veg" 
                className="flex items-center space-x-2 text-lg py-3"
              >
                <Utensils className="h-5 w-5" />
                <span>Non-Vegetarian</span>
              </TabsTrigger>
            </TabsList>

            {/* Vegetarian Menu */}
            <TabsContent value="veg" className="space-y-8">
              <div className="text-center mb-8">
                <Badge variant="secondary" className="mb-4 px-4 py-2 text-sm">
                  <Leaf className="h-4 w-4 mr-2" />
                  Pure Vegetarian Delights
                </Badge>
                <Button 
                  onClick={() => downloadMenu('Vegetarian')}
                  variant="outline"
                  className="ml-4"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vegMenuItems.map((category, index) => (
                  <Card key={index} className="hover:shadow-soft transition-all duration-300 hover:-translate-y-1 border-border">
                    <CardHeader className="pb-4">
                      <CardTitle className="text-xl text-foreground flex items-center">
                        <Star className="h-5 w-5 text-primary mr-2" />
                        {category.category}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {category.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-center text-muted-foreground">
                            <div className="w-2 h-2 bg-primary rounded-full mr-3 flex-shrink-0"></div>
                            <span className="text-sm">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Non-Vegetarian Menu */}
            <TabsContent value="non-veg" className="space-y-8">
              <div className="text-center mb-8">
                <Badge variant="secondary" className="mb-4 px-4 py-2 text-sm bg-spice-red/10 text-spice-red">
                  <Utensils className="h-4 w-4 mr-2" />
                  Non-Vegetarian Specialties
                </Badge>
                <Button 
                  onClick={() => downloadMenu('Non-Vegetarian')}
                  variant="outline"
                  className="ml-4"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {nonVegMenuItems.map((category, index) => (
                  <Card key={index} className="hover:shadow-soft transition-all duration-300 hover:-translate-y-1 border-border">
                    <CardHeader className="pb-4">
                      <CardTitle className="text-xl text-foreground flex items-center">
                        <Star className="h-5 w-5 text-spice-red mr-2" />
                        {category.category}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {category.items.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-center text-muted-foreground">
                            <div className="w-2 h-2 bg-spice-red rounded-full mr-3 flex-shrink-0"></div>
                            <span className="text-sm">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          {/* Call to Action */}
          <div className="text-center mt-16">
            <Card className="bg-gradient-to-r from-primary-light to-warm-cream border-border p-8">
              <h3 className="text-2xl font-bold mb-4 text-foreground">
                Can't find what you're looking for?
              </h3>
              <p className="text-muted-foreground mb-6">
                We offer customizable menus to suit your specific requirements and preferences.
              </p>
              <Button 
                onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-primary hover:bg-primary-dark"
              >
                Contact Us for Custom Menu
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};